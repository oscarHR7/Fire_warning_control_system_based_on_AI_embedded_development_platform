#include"reg52.h"
#include"dynamic_led_design/dynamic_led_design.h"
#include"LCD1206/lcd.h"
#include"ds1302/ds1302.h"
#include"rs485/rs485.h"
sbit SHOW_WARNNING=P3^7;
sbit LED_WARNNING=P1^2;
unsigned char order_flag = 0;//����STM32��51ǰ�˵�ָ��
void main()
{
		Int0Configuration();
		Ds1302Init();
		UsartInit();
		
while (1)         //��ѭ��
  {
		LED_WARNNING = 1;
		LED_GREEN = 1;
		SHOW_WARNNING = 1;
		LcdInit();
		while (common_open) 
		{
			LED_GREEN = 0;
			if(!common_open)
				{
						break;
				}
			while(common_warnning)
			{
				LED_GREEN = 1;
				LCD_run();
				LED_WARNNING = 0;
				_delay(5000);
				if(!common_warnning)
				{
					  LED_WARNNING = 1;
						break;
				}
			}				
				led_run(); 
			  LCD_run();
		}
		    
  }
}
	