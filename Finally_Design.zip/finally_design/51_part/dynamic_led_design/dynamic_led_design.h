#ifndef _led_H_
#define _led_H_
#include"reg52.h"
//--�ض��庯������--//
#define uchar unsigned char
#define uint  unsigned int
#define ulong unsigned long

//--����SPIҪʹ�õ� IO--//
sbit MOSIO = P2^4;
sbit R_CLK = P2^2;
sbit S_CLK = P2^3;





void HC595SendData( uchar BT3, uchar BT2,uchar BT1,uchar BT0);
void led_run(void);
#endif