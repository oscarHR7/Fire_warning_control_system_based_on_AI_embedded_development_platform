import sensor, image, time
from pyb import Pin, SPI,UART

cs  = Pin("P9", Pin.OUT_OD)
rst = Pin("P7", Pin.OUT_PP)
rs  = Pin("P8", Pin.OUT_PP)
bl  = Pin("P6", Pin.OUT_PP)     # 背光控制
spi = SPI(2, SPI.MASTER, baudrate=int(10000000000/66*0.06), polarity=0, phase=0,bits=8)
uart = UART(3,9600,timeout_char = 1000)
threshold_index = 0
thresholds = [(30, 100, 15, 127, 15, 127)]



# SPI 写命令
def write_command_byte(c):
    cs.low()
    rs.low()
    spi.send(c)
    cs.high()

# SPI 写数据
def write_data_byte(c):
    cs.low()
    rs.high()
    spi.send(c)
    cs.high()

def write_command(c, *data): #命令数据一起写，先写命令 第二个开始为数据位。如果只写一个，则代表不写数据只写命令。
    write_command_byte(c)
    if data:
        for d in data:
            if d > 255:
                write_data_byte(d >> 8)
                write_data_byte(d&0xFF)
            else:
                write_data_byte(d)

def write_image(img):
    cs.low()
    rs.high()
    fbuf = bytearray(320)
    for m in img: 					#把一帧图像的对象取出来，放到帧缓存区中
        fbuf=m
        for i in range(0,320):		#每行每行的发送
            spi.send(fbuf[i])	    #先发第N行的第I个数据的低八位
            spi.send(fbuf[i]>>8)	#再发高八位

    cs.high()

def SetRegion(xStar, yStar, xEnd, yEnd):
    write_command(0x2A, xStar>>8, xStar&0XFF, xEnd>>8, xEnd&0XFF)
    write_command(0x2B, yStar>>8, yStar&0XFF, yEnd>>8, yEnd&0XFF)
    write_command(0x2C)


def LCDinit():
    rst.low()
    time.sleep(100)
    rst.high()
    time.sleep(100)

    write_command(0xCB, 0x39, 0x2c, 0x00, 0x34, 0x02)
    write_command(0xCF, 0x00, 0XAA, 0XE0)
    write_command(0xE8, 0x85, 0x11, 0x78)
    write_command(0xEA, 0x00, 0x00)
    write_command(0xED, 0x67, 0x03, 0X12, 0X81)
    write_command(0xF7, 0x20)
    write_command(0xC0, 0x21)       # Power control, VRH[5:0]
    write_command(0xC1, 0x11)       # Power control, SAP[2:0];BT[3:0]
    write_command(0xC5, 0x24, 0x3C) # VCM control, 对比度调节
    write_command(0xC7, 0xB7)       # VCM control2, --
    write_command(0x36, 0xE8)
    X_MIN_PIXEL = 0
    Y_MIN_PIXEL = 0
    X_MAX_PIXEL = 320               # 定义屏幕宽度
    Y_MAX_PIXEL = 240               # 定义屏幕高度
    SetRegion(0, 0, X_MAX_PIXEL - 1, Y_MAX_PIXEL - 1)
    write_command(0x3A, 0x55)
    write_command(0xB1, 0x00, 0x18)
    write_command(0xB6, 0x08, 0x82, 0x27)   # Display Function Control
    write_command(0xF2, 0x00)               # 3Gamma Function Disable
    write_command(0x26, 0x01)               # Gamma curve selected
    write_command(0xB7, 0x06)
    write_command(0xE0, 0x0F, 0x31, 0x2B, 0x0C, 0x0E, 0x08, 0x4E, 0xF1, 0x37, 0x07, 0x10, 0x03, 0x0E, 0x09, 0x00)
    write_command(0XE1, 0x00, 0x0E, 0x14, 0x03, 0x11, 0x07, 0x31, 0xC1, 0x48, 0x08, 0x0F, 0x0C, 0x31, 0x36, 0x0F)
    write_command(0x11) # sleep_ms Exit
    time.sleep(120)
    write_command(0x29)
    write_command(0x2C)
    bl.high()   # 拉背光

def LCDdisplay(img):
    write_command(0x2C)
    write_image(img)

sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time = 2000)
sensor.set_auto_gain(False) # must be turned off for color tracking
sensor.set_auto_whitebal(False) # must be turned off for color tracking

clock = time.clock()
LCDinit()

Warnning_flag =0
a = '\x01'


while(True):

    img = sensor.snapshot()
    LCDdisplay(img)
    for blob in img.find_blobs([thresholds[threshold_index]], pixels_threshold=200, area_threshold=200, merge=True):
        Warnning_flag = 1
    if(Warnning_flag == 1):
        F = bytearray([0x2C,0x12,0x2F,0x5B])
        uart.write(F)
        print(2)
        Warnning_flag = 0;
    else:
        print(1)
    if uart.any():
        a = uart.readline()
    if(a == b'\x01'):
        Warnning_flag = 0
        LCDinit()









