#include "../HARDWARE/lcd_show/lcd_show.h"
#include "../HARDWARE/lcd/lcd.h"
#include "../HARDWARE/rs485/rs485.h"
#include "../HARDWARE/key/key.h"
#include "../SYSTEM/usart/usart.h"
#define Common_on  '1'
#define Common_off '0'
#define Common_open_warnning  '2'
#define Common_close_warnning '3'
#define Common_open_mv  0
#define Common_close_mv 1

u8 Flag = 1;
u8 Interface = 1;
u8 buf[1];



void	FLASH_one(void)
{
					Flag = 1;
					LCD_Fill(0,0,30,250,WHITE);
					LCD_DrawLine(0,40,30, 55);
					LCD_DrawLine(30,55,0,70);
}
void	FLASH_two(void)
{					
					Flag = 2;
					LCD_Fill(0,0,30,250,WHITE);
					LCD_DrawLine(0,40+30,30, 55+30);
					LCD_DrawLine(30,55+30,0,70+30);
}
void	FLASH_three(void)
{					
					Flag = 3;
					LCD_Fill(0,0,30,250,WHITE);
					LCD_DrawLine(0,40+60,30, 55+60);
					LCD_DrawLine(30,55+60,0,70+60);
}
void	FLASH_four(void)
{
					Flag = 4;
					LCD_Fill(0,0,30,250,WHITE);
					LCD_DrawLine(0,40+90,30,55+90);
					LCD_DrawLine(30,55+90,0,70+90);
}
void	FLASH_five(void)
{
					Flag = 5;
					LCD_Fill(0,0,30,250,WHITE);
					LCD_DrawLine(0,40+120,30,55+120);
					LCD_DrawLine(30,55+120,0,70+120);
}
void	FLASH_six(void)
{
					Flag = 6;
					LCD_Fill(0,0,30,250,WHITE);
					LCD_DrawLine(0,40+150,30,55+150);
					LCD_DrawLine(30,55+150,0,70+150);
}
void	LCD_KEY_UP(void)
{
						if(Flag==1)
													{
															FLASH_six();
													}
						else	if(Flag==2)
													{
															FLASH_one();
													}
						else	if(Flag==3)
													{
															FLASH_two();
													}
						else	if(Flag==4)
													{
															FLASH_three();
													}
						else	if(Flag==5)
													{
															FLASH_four();
													}
						else	if(Flag==6)
													{
															FLASH_five();
													}
													

}
void	LCD_KEY_DOWN(void)
{
					if(Flag==1)
													{
															FLASH_two();
													}
						else	if(Flag==2)
													{
															FLASH_three();
													}
						else	if(Flag==3)
													{
															FLASH_four();
													}
						else	if(Flag==4)
													{
															FLASH_five();
													}
						else	if(Flag==5)
													{
															FLASH_six();
													}
						else	if(Flag==6)
													{
															FLASH_one();
													}
}

void	fountion_A(void)
{
	buf[0]=Common_on;
	RS485_Send_Data(buf,1);
	LCD_ShowString(30,70,210,16,24 ,"Successful_open");
}


void	fountion_B(void)
{
	buf[0]=Common_off;
	RS485_Send_Data(buf,1);
  LCD_ShowString(30,70,210,16,24 ,"Successful_close");
}

void	fountion_C(void)
{
		buf[0]=Common_open_warnning;
		RS485_Send_Data(buf,1);
		LCD_ShowString(30,100,210,16,24, "Successful_Send");
}

void	fountion_D(void)
{
		buf[0]=Common_close_warnning;
	  RS485_Send_Data(buf,1);
		LCD_ShowString(30,130,210,16,24, "Successful_Eiminate");
}

void	fountion_E(void)
{
		USART_SendData(USART1, Common_open_mv);//�򴮿�1��������
		while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET);//�ȴ����ͽ���
		LCD_ShowString(30,130,210,16,24, "Successful_Open");
}

void	fountion_F(void)
{
		USART_SendData(USART1, Common_close_mv);//�򴮿�1��������
		while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET);//�ȴ����ͽ���
		personal = 99;
		personal_last = 99;
		LCD_ShowString(30,130,210,16,24, "Successful_Close");
}

void	LCD_KEY_SURE(void)
{
					Interface = 2;
					LCD_Fill(0,0,240,360,WHITE);
					if(Flag==1)
													{
															fountion_A();
													}
						else	if(Flag==2)
													{
															fountion_B();
													}
						else	if(Flag==3)
													{
															fountion_C();
													}
						else	if(Flag==4)
													{
															fountion_D();
													}
						else	if(Flag==5)
													{
															fountion_E();
													}
						else	if(Flag==6)
													{
															fountion_F();
													}
}

void 	LCD_First_interface(void)
{
		LCD_Fill(0,0,450,450,WHITE);
		LCD_DrawLine(0,40,30, 55);
		LCD_DrawLine(30,55,0,70);
		LCD_ShowString(30,40,210,16,24,"System_open"); 
		LCD_ShowString(30,70,210,16,24 ,"System_close");
		LCD_ShowString(30,100,210,16,24, "Send_Warnning");
		LCD_ShowString(30,130,210,16,24, "Elminate_Warnning");
		LCD_ShowString(30,160,210,16,24, "Open_living");
		LCD_ShowString(30,190,210,16,24, "Close_living");	
		LCD_ShowString(70,360,210,24,24," Welcome HR7 ");
}
void 	LCD_KEY_BACK(void)
{
		Interface = 1;
		Flag = 1;
		LCD_First_interface();
}

