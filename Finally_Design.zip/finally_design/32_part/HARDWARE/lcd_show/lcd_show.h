#ifndef _LCD_SHOW_H
#define	_LCD_SHOW_H
extern	unsigned char Flag;
extern	unsigned char Interface;
#include "stm32f10x.h"
void	LCD_KEY_UP(void);
void	LCD_KEY_DOWN(void);
void	LCD_KEY_SURE(void);
void 	LCD_First_interface(void);
void 	LCD_KEY_BACK(void);


#endif 
