#include "sys.h"
#include "delay.h"
#include "../SYSTEM/usart/usart.h"
#include "../HARDWARE/key/key.h"
#include "../HARDWARE/lcd/lcd.h"
#include "../HARDWARE/lcd_show/lcd_show.h"
#include "../HARDWARE/passwords/passwords.h"
#include "../HARDWARE/rs485/rs485.h"

int main(void)
 {		
	  u8 key_num=0;
	  
		NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//�����ж����ȼ�����Ϊ��2��2λ��ռ���ȼ���2λ��Ӧ���ȼ�
		delay_init();	    	 //��ʱ������ʼ��	  
		uart_init(9600);	 //���ڳ�ʼ��Ϊ115200 openmv����
		InitKey(); 
	  KEY_Init();
		LCD_Init();
	  RS485_Init(4800);		//���ڳ�ʼ��51	4800
		POINT_COLOR=RED;
		LCD_ShowString(15,60,210,24,24,"FZU_Control_System");
		LCD_ShowString(15,120,210,24,24,"User_name:");
		LCD_ShowString(15,240,210,24,24,"U_password:");
		while(1)
{

	if(!information_finish_flag)//�����˺�
		{
			key_num=key();
			if(key_num >= 0 && key_num<= 9)
				{
					 input_information(key_num);
				}
				if(key_num == 10)
			{			
				LCD_Fill(100+(now_information_pointers+3)*12,128,100+(now_information_pointers+4)*12,144,WHITE);
				--now_information_pointers;
			}
			if(key_num == 11)
			{
				information_finish_flag = 1;
			}
			
		}
  if(!passwords_finish_flag&&information_finish_flag==1)//��������
	{
		
		key_num=key();
		if(key_num >= 0 && key_num<= 9)
			{
				 input_passwords(key_num);
			}
			if(key_num == 10)
			{			
				LCD_Fill(100+(now_passwords_pointers+3)*12,248,100+(now_passwords_pointers+4)*12,264,WHITE);
				--now_passwords_pointers;
			}
		if(key_num == 11)//����˺������ƥ���
			{
				passwords_finish_flag = 1;//������ɱ�־
					 for(passwords_test_pointer = 0;passwords_test_pointer < 9;passwords_test_pointer++)
							 {
								 if(user_now_information[passwords_test_pointer] != user_information[passwords_test_pointer] )
									{		
													re_enter = 0;
													break;
									}
								 
									if(user_now_passwords[passwords_test_pointer] != user_passwords[passwords_test_pointer] )
									{		
													re_enter = 0;
													break;
									}
							 }
						if(passwords_test_pointer<9)
						{
							while(!re_enter)
							{
								LCD_ShowString(80,320,210,24,16,"password fail");	
								LCD_ShowString(70,336,210,24,16,"Press A to re-enter");
								delay_ms(2000);
								LCD_Fill(70,320,226,360,WHITE);
								delay_ms(2000);
								key_num=key();
								if(key_num == 'A')//������������ٴν�������
								{
									re_enter = 1;
									information_finish_flag = 0;
									now_information_pointers = 0;
									passwords_finish_flag = 0;
									now_passwords_pointers = 0;
									clear_now_information();
									clear_now_passwords();
									LCD_Fill(0,0,400,400,WHITE);
									LCD_ShowString(15,60,210,24,24,"FZU_Control_System");
									LCD_ShowString(15,120,210,24,24,"User_name:");
									LCD_ShowString(15,240,210,24,24,"U_password:");
								}
							}
						}
						else//������һ�����������ڲ���������
						{
							 passwords_finish_flag = 1;	
							 LCD_First_interface();
						}
			}
	}
	if(passwords_finish_flag == 1)
	{
		
		_key = KEY_Scan(0);
		if(Interface == 1)
		{
			switch(_key)
				{
						case KEY_UP:		LCD_KEY_UP();		break;
						case KEY_DOWN:	LCD_KEY_DOWN();	break;
						case KEY_SURE:	LCD_KEY_SURE();	break;
				}	
				
				if(personal != personal_last)
			{
					LCD_ShowString(80,320,210,24,16,"Find Abnormal");	
					LCD_ShowString(70,336,210,24,16,"Please Open Living");
					delay_ms(80);
					LCD_Fill(70,320,226,360,WHITE);
			}
					
					
					
					
		}
		else	if(Interface == 2)
		{
			switch(_key)
				{
							case KEY_SURE:	LCD_KEY_BACK();	break;
				}		
		}
	}
		
		delay_ms(20);
	}
} 

